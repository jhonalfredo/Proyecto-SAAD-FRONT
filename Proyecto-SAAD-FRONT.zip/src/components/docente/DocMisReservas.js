import React from 'react'
import MenuDoc from './MenuDoc'

export default function DocMisReservas() {
  return (
    <div>
        <MenuDoc/>
        <h1>mis reservas</h1>
    </div>
  )
}
