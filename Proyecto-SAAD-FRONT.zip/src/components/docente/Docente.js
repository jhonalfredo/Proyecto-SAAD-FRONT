import React from 'react'
import Menu from '../Menu'
import MenuDoc from './MenuDoc'

export default function Docente() {
  return (
    <div>
      <MenuDoc/>
      <h1>Home docente</h1>
    </div>
    
  )
}
