export default class DatosApp{
    static getHorarios(){
        var datos = ["6:45", "8:15", "9:45", "11:15", "12:45", "14:15", "15:45", "17:15", "18:45", "20:15"];
        return datos;
    }

    static getHorariosFin(){
        var datos = ["8:15", "9:45", "11:15", "12:45", "14:15", "15:45", "17:15", "18:45", "20:15", "21:45"];
        return datos;
    }

    static getDatosMateria(){
        var datos = ["Introduccion a la programacion", "Elementos de programacion", "Taller de Ingenieria de sotfware", "Arquitectura de computadoras"];
        return datos;
    }
}