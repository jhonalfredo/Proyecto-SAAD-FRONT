import React from 'react'
import MenuAdmin from './MenuAdmin'
export default function Administrador() {
  return (
    <div>
      <MenuAdmin/>
      <h1>Home</h1>
    </div>
  )
}
