import React from 'react'
import MenuAdmin from './MenuAdmin'

export default function AdmAceptSolDocente() {
  return (
    <div>
        <MenuAdmin/>
        AdmAceptSolDocente    
    </div>
  )
}
